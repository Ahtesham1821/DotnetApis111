﻿using EmployeeDataAssing.Models;
using EmployeeDataAssing.Response;

namespace EmployeeDataAssing.Repository
{
    public class EmployeeData : IEmployeeData
    {
        public ResponseCls DeleteData(int EmployeeId)

        {
            ResponseCls responseMsg = new ResponseCls();
            GetDataResponse response = new GetDataResponse();
            sdirectdbContext db = new sdirectdbContext();
            var data = db.EmployeeAssignment2023s.FirstOrDefault(i => i.EmployeeId == EmployeeId);
            if (data.EmployeeId != null)
            {
                data.IsDeleted = true;
                data.IsActive = false;
                db.SaveChanges();
                responseMsg.ResponseMsg = "Record Deleted Succesfully";
                return responseMsg;


            }
            else
            {
                responseMsg.ResponseMsg = "404 Data not found";
                return responseMsg;
            }

        }

        public GetDataResponse GetEmployeeById(int EmployeeId)
        {
            GetDataResponse GetDataResponseById = new GetDataResponse();
            sdirectdbContext db = new sdirectdbContext();
            var objData = (from emp in db.EmployeeAssignment2023s
                           where emp.EmployeeId == EmployeeId
                           select new GetDataResponse
                           {
                               EmployeeId = emp.EmployeeId,
                               EmployeeName = emp.EmployeeName,
                               EmployeeAge = emp.EmployeeAge,
                               EmployeePhoneNumber = emp.EmployeePhoneNumber,
                               EmployeeEmail = emp.EmployeeEmail,
                               EmployeeAddress = emp.EmployeeAddress,
                               IsActive = emp.IsActive

                           }).FirstOrDefault();
            GetDataResponseById = objData;
            return GetDataResponseById;

        }

        public List<GetDataResponse> GetEmployeeData()
        {

            List<GetDataResponse> getDataResponses = new List<GetDataResponse>();
            sdirectdbContext db = new sdirectdbContext();
            var objData = (from emp in db.EmployeeAssignment2023s
                           select new GetDataResponse
                           {
                               EmployeeId = emp.EmployeeId,
                               EmployeeName = emp.EmployeeName,
                               EmployeeAge = emp.EmployeeAge,
                               EmployeePhoneNumber = emp.EmployeePhoneNumber,
                               EmployeeEmail = emp.EmployeeEmail,
                               EmployeeAddress = emp.EmployeeAddress,
                               IsActive = emp.IsActive


                           }
                           ).ToList();

            getDataResponses = objData;


            return getDataResponses;
        }

        public bool PostData(EmployeeAssignment2023 emp)
        {
            sdirectdbContext db = new sdirectdbContext();
            var data = db.EmployeeAssignment2023s.Where(h => h.EmployeeEmail == emp.EmployeeEmail || h.EmployeePhoneNumber == emp.EmployeePhoneNumber).FirstOrDefault();
          
            if (data != null)
            {
              return false;
            }
            else
            {
                db.EmployeeAssignment2023s.Add(emp);
                db.SaveChanges();
                Console.WriteLine("working");
                return true;
            }


        }


    
        



        public ResponseCls UpdateData(EmployeeAssignment2023 emp)
        {
            ResponseCls responseMsg = new ResponseCls();
            sdirectdbContext db = new sdirectdbContext();
            var data = db.EmployeeAssignment2023s.FirstOrDefault(h => h.EmployeeId == emp.EmployeeId);
            if (data.EmployeeId != null)
            {

                data.EmployeeName = emp.EmployeeName;
                data.EmployeeAge = emp.EmployeeAge;
                data.EmployeePhoneNumber = emp.EmployeePhoneNumber;
                data.EmployeeEmail = emp.EmployeeEmail; 
                data.EmployeeAddress =   emp.EmployeeAddress;
                data.IsActive = emp.IsActive;
                db.SaveChanges();

                responseMsg.ResponseMsg = "Record Updated";
                    return responseMsg;


            }
            responseMsg.ResponseMsg = "Record Not Updated";
            return responseMsg;
        }

    }
}

