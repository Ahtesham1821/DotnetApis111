﻿using EmployeeDataAssing.Models;
using EmployeeDataAssing.Response;
using System.ComponentModel.DataAnnotations;

namespace EmployeeDataAssing.Repository
{
    public interface IEmployeeData
    {

        public List<GetDataResponse> GetEmployeeData();

        public GetDataResponse GetEmployeeById(int EmployeeId);

        public ResponseCls UpdateData(EmployeeAssignment2023 emp);

        public ResponseCls DeleteData(int EmployeeId);

       
        public bool PostData(EmployeeAssignment2023 emp);


    }
}
