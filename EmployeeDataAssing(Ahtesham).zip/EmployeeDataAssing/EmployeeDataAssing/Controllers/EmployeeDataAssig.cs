﻿using EmployeeDataAssing.Models;
using EmployeeDataAssing.Repository;
using EmployeeDataAssing.Response;
using Microsoft.AspNetCore.Mvc;

namespace EmployeeDataAssing.Controllers
{
    public class EmployeeDataAssig : Controller
    {
        private readonly IEmployeeData _IEmployeeDatas;

        public EmployeeDataAssig(IEmployeeData iEmployeeData)
        {
            _IEmployeeDatas = iEmployeeData;
        }

        [HttpGet]
        [Route("GetEmployeeData")]
        public IActionResult GetEmployeeData()
        {
            var v= _IEmployeeDatas.GetEmployeeData();
            return Ok(v);
        }

        [HttpGet]
        [Route("GetElementById")]
        public IActionResult GetEmployeeById(int EmployeeId)
        {

          var obj =_IEmployeeDatas.GetEmployeeById( EmployeeId);
            return Ok(obj);
        }

        [HttpPut]
        [Route("UpdateEmployeeData")]

        public IActionResult UpdateData(EmployeeAssignment2023 emp)
        {
            _IEmployeeDatas.UpdateData(emp);
            return Ok();
        }

        [HttpDelete]
        [Route("DeleteEmploye/EmployeeId")]

        public IActionResult DeleteData(int EmployeeId) { 
            ResponseCls rs = new ResponseCls();
        _IEmployeeDatas.DeleteData(EmployeeId);
            rs.ResponseMsg = "Data has been Deleted ";
            return Ok(rs);
        }

        [HttpPost]
        [Route("AddingData")]

        public IActionResult PostData(EmployeeAssignment2023 emp)
        {

            var data =_IEmployeeDatas.PostData(emp);
            return Ok(data);
        }
    }
}
