﻿using System.ComponentModel;

namespace EmployeeDataAssing.Response
{
    public class GetDataResponse
    {
        public int EmployeeId { get; set; }
        public string EmployeeName { get; set; } = null!;
        public int EmployeeAge { get; set; }
        public long EmployeePhoneNumber { get; set; }
        public string EmployeeEmail { get; set; } = null!;
        public string? EmployeeAddress { get; set; }

        [DefaultValue(true)]
        public bool? IsActive { get; set; }
      
    }
}
