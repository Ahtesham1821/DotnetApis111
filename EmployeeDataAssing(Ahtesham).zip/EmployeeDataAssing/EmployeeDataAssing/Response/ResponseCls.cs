﻿namespace EmployeeDataAssing.Response
{
    public class ResponseCls
    {
   
        public GetDataResponse get { get; set; }
        public string ResponseMsg { get; set; }
    }
}
