﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace EmployeeDataAssing.Models
{
    public partial class EmployeeAssignment2023
    {
        public int EmployeeId { get; set; }
        public string EmployeeName { get; set; } = null!;
        public int EmployeeAge { get; set; }
        [Required]
        public long EmployeePhoneNumber { get; set; }

        [Required]
        public string EmployeeEmail { get; set; } = null!;
        public string? EmployeeAddress { get; set; }

        [DefaultValue(true)]
        public bool? IsActive { get; set; }

        [DefaultValue(false)]
        public bool? IsDeleted { get; set; }
    }
}
